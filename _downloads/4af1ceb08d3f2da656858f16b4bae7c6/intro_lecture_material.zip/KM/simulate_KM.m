function SimuRslt = simulate_KM(IterRslt,GNDSGE_OPTIONS)
TolEq = 1e-6;
TolSol = 1e-8;
TolFun = 1e-8;
PrintFreq = 10;
SaveFreq = 10;
SimuPrintFreq = 1000;
SimuSaveFreq = inf;
NumThreads = feature('numcores');
MaxIter = inf;
MaxMinorIter = inf;
num_samples = 1;
num_periods = 1000;
SolMaxIter = 200;

% task constants
MEX_TASK_INIT = 0;
MEX_TASK_INF_HORIZON = 1;

% DEBUG flag
GNDSGE_DEBUG_EVAL_ONLY = 0;

INTERP_ORDER = 4;
EXTRAP_ORDER = 2;
OutputInterpOrder = 2;
USE_SPLINE = 1;
GNDSGE_USE_OLD_VEC = 0;
USE_ASG = 0;
USE_PCHIP = 0;
SIMU_INTERP = 0;
SIMU_RESOLVE = 1;
SimuSeed = 0823;
AsgMinLevel = 4;
AsgMaxLevel = 10;
AsgThreshold = 1e-2;
AsgOutputMaxLevel = 10;
AsgOutputThreshold = 1e-2;
IterSaveAll = 0;
SkipModelInit = 0;
GNDSGE_EMPTY = [];
GNDSGE_ASG_FIX_GRID = 0;
UseModelId = 0;
MinBatchSol = 1;
UseAdaptiveBound = 1;
UseAdaptiveBoundInSol = 0;
EnforceSimuStateInbound = 1;
rng(0823);
DEFAULT_PARAMETERS_END_HERE = true;
a = 0.7;
c = 0.3;
alower=0.9;
sigma=1;
betaF=0.95;
betaG=0.98;
alpha=0.7;
Kbar=1;
theta=0.9;
INTERP_ORDER = 2;
EXTRAP_ORDER = 2;
PrintFreq = 100;
SaveFreq = 100;
SIMU_RESOLVE=0;
SIMU_INTERP=1;
kFPts=41;
kFMin=0.02;
kFMax=0.95;
kF=linspace(kFMin,kFMax,kFPts);
omegaPts=40;
omegaMin=0;
omegaMax=0.2;
omega=linspace(omegaMin,omegaMax,omegaPts);
shock_num=3;
A = [0.99 1 1.01];
shock_trans = ones(shock_num,shock_num)/shock_num;
num_periods = 1000;
num_samples = 100;


GEN_SHOCK_START_PERIOD=1;

v2struct(IterRslt.var_state);

%% Overwrite parameters
if nargin>=2
    v2struct(GNDSGE_OPTIONS)
end

%% Reconstruct interpolations
GNDSGE_PP = IterRslt.output_interp;

shock_trans = IterRslt.shock_trans;
output_var_index = IterRslt.output_var_index;

%% Construct space
SimuRslt.shock = ones(num_samples,num_periods+1);
SimuRslt.kF=zeros(num_samples,num_periods);
SimuRslt.omega=zeros(num_samples,num_periods);
SimuRslt.xF=zeros(num_samples,num_periods);
SimuRslt.xG=zeros(num_samples,num_periods);
SimuRslt.Y=zeros(num_samples,num_periods);
SimuRslt.q=zeros(num_samples,num_periods);
SimuRslt.R=zeros(num_samples,num_periods);
SimuRslt.eta=zeros(num_samples,num_periods);
SimuRslt.muF=zeros(num_samples,num_periods);
SimuRslt.bF=zeros(num_samples,num_periods);


%% Initiate state
SimuRslt.kF(:,1)=0.05;
SimuRslt.omega(:,1)=0.01;
SimuRslt.shock(:,1)=2;


if nargin>1 && isfield(GNDSGE_OPTIONS,'init')
    SimuRslt.kF(:,1:size(GNDSGE_OPTIONS.init.kF,2))=GNDSGE_OPTIONS.init.kF;
SimuRslt.omega(:,1:size(GNDSGE_OPTIONS.init.omega,2))=GNDSGE_OPTIONS.init.omega;
SimuRslt.shock(:,1:size(GNDSGE_OPTIONS.init.shock,2))=GNDSGE_OPTIONS.init.shock;

end

if any(SimuRslt.shock(:,1)>shock_num)
    error('initial shock exceeds shock_num');
end

%% Generate random number
SimuRslt.shock(:,GEN_SHOCK_START_PERIOD:end) = gen_discrete_markov_rn(shock_trans,num_samples,length(GEN_SHOCK_START_PERIOD:num_periods+1),...
    SimuRslt.shock(:,GEN_SHOCK_START_PERIOD),SimuSeed);

%% Apply the interpolation for simulation
shock_num = size(shock_trans,1);
GNDSGE_SHOCK_VAR_INDEX_BASE = ([0:num_samples-1]')*shock_num;
for GNDSGE_t=1:num_periods
    % constrain states inbound
    if EnforceSimuStateInbound==1
        SimuRslt.kF(:,GNDSGE_t)=max(min(IterRslt.var_state.kF),SimuRslt.kF(:,GNDSGE_t));
SimuRslt.kF(:,GNDSGE_t)=min(max(IterRslt.var_state.kF),SimuRslt.kF(:,GNDSGE_t));
SimuRslt.omega(:,GNDSGE_t)=max(min(IterRslt.var_state.omega),SimuRslt.omega(:,GNDSGE_t));
SimuRslt.omega(:,GNDSGE_t)=min(max(IterRslt.var_state.omega),SimuRslt.omega(:,GNDSGE_t));

    end
    
    % Intepolate values
    GNDSGE_INTERP_RESULTS = myinterp_mex(int32(NumThreads),GNDSGE_PP.breaks,GNDSGE_PP.coefs,int32(GNDSGE_PP.pieces),int32(GNDSGE_PP.order),int32(GNDSGE_PP.dim),'not-a-knot',[SimuRslt.shock(:,GNDSGE_t)';SimuRslt.kF(:,GNDSGE_t)';SimuRslt.omega(:,GNDSGE_t)'],[],[],[]);
    
    % Assign to output variables from evaluation results
    xF=GNDSGE_INTERP_RESULTS(output_var_index.xF,:);
xG=GNDSGE_INTERP_RESULTS(output_var_index.xG,:);
Y=GNDSGE_INTERP_RESULTS(output_var_index.Y,:);
q=GNDSGE_INTERP_RESULTS(output_var_index.q,:);
R=GNDSGE_INTERP_RESULTS(output_var_index.R,:);
eta=GNDSGE_INTERP_RESULTS(output_var_index.eta,:);
muF=GNDSGE_INTERP_RESULTS(output_var_index.muF,:);
kFnext=GNDSGE_INTERP_RESULTS(output_var_index.kFnext,:);
omega_next=GNDSGE_INTERP_RESULTS(output_var_index.omega_next,:);
bF=GNDSGE_INTERP_RESULTS(output_var_index.bF,:);

    
    % Move states forward
    % Linear index
    GNDSGE_SHOCK_VAR_LINEAR_INDEX = SimuRslt.shock(:,GNDSGE_t+1) + GNDSGE_SHOCK_VAR_INDEX_BASE;
    SimuRslt.xF(:,GNDSGE_t)=xF;
SimuRslt.xG(:,GNDSGE_t)=xG;
SimuRslt.Y(:,GNDSGE_t)=Y;
SimuRslt.q(:,GNDSGE_t)=q;
SimuRslt.R(:,GNDSGE_t)=R;
SimuRslt.eta(:,GNDSGE_t)=eta;
SimuRslt.muF(:,GNDSGE_t)=muF;
SimuRslt.bF(:,GNDSGE_t)=bF;
SimuRslt.kF(:,GNDSGE_t+1)=kFnext(:);

SimuRslt.omega(:,GNDSGE_t+1) = omega_next(GNDSGE_SHOCK_VAR_LINEAR_INDEX);



    
    
    
    % Print something
    if mod(GNDSGE_t,SimuPrintFreq)==0
        fprintf('Periods: %d\n', GNDSGE_t);
        SimuRsltNames = fieldnames(SimuRslt);
        for GNDSGE_field = 1:length(SimuRsltNames)
            fprintf('%8s', SimuRsltNames{GNDSGE_field});
        end
        fprintf('\n');
        for GNDSGE_field = 1:length(SimuRsltNames)
            fprintf('%8.4g', SimuRslt.(SimuRsltNames{GNDSGE_field})(1,GNDSGE_t));
        end
        fprintf('\n');
    end
    
    if mod(GNDSGE_t,SimuSaveFreq)==0
        save(['SimuRslt_KM_' num2str(GNDSGE_t) '.mat'], 'SimuRslt');
    end
end

end