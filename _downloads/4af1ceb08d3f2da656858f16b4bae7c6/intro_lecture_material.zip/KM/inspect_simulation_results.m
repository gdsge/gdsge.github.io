num_periods = length(SimuRslt.kF);
startPeriods = round(num_periods/10);

v2struct(IterRslt);
v2struct(IterRslt.params);

kF = SimuRslt.kF(:,startPeriods:end-1);
q = SimuRslt.q(:,startPeriods:end);
omega = SimuRslt.omega(:,startPeriods:end-1);
Y = SimuRslt.Y(:,startPeriods:end);
R = SimuRslt.R(:,startPeriods:end);
xF = SimuRslt.xF(:,startPeriods:end);
xG = SimuRslt.xG(:,startPeriods:end);
muF = SimuRslt.muF(:,startPeriods:end);
eta = SimuRslt.eta(:,startPeriods:end);

shock = SimuRslt.shock(:,startPeriods:end-1);

binding_cc = (muF>1e-4);
omega_bd = omega(binding_cc==1);
omega_nbd = omega(binding_cc==0);
kF_bd = kF(binding_cc==1);
kF_nbd = kF(binding_cc==0);


figure(45);clf;
subplot(1,2,1);
hold on;
h1 = histogram(kF_bd,30);
h2 = histogram(kF_nbd,30);
title('Distribution of $k$','Interpreter','Latex');
xlabel('$k$','Interpreter','Latex');
ylabel('No. of Counts');
AX = legend('Binding CC','Non-binding CC');
set(gca,'FontSize',15);

subplot(1,2,2);
hold on;
h1 = histogram(omega_bd,30);
h2 = histogram(omega_nbd,30);
title('Distribution of $\omega$','Interpreter','Latex');
xlabel('$\omega$','Interpreter','Latex');
ylabel('No. of Counts');
set(gca,'FontSize',15);


disp(['Prob of binding CC:  ',num2str(sum(muF(:)>=1e-4)/numel(muF))]);
disp(['Prob of binding CC in state 1:  ',num2str(sum(muF(:)>=1e-4&shock(:)==1)/sum(shock(:)==1))]);
disp(['Prob of binding CC in state 2:  ',num2str(sum(muF(:)>=1e-4&shock(:)==2)/sum(shock(:)==2))]);
disp(['Prob of binding CC in state 3:  ',num2str(sum(muF(:)>=1e-4&shock(:)==3)/sum(shock(:)==3))]);
disp(['Prob of binding nontradable consumption:  ',num2str(sum(eta(:)>=1e-4)/numel(eta))]);
disp(['Average kF in Normal state:  ',num2str(mean(kF(shock(:)==2)))]);
disp(['Average omega in Normal state:  ',num2str(mean(omega(shock(:)==2)))]);

