clc;clear;close all;

% gndsge_codegen('KM');

IterRslt = iter_KM;
save('IterRslt_KM.mat','IterRslt');

load('IterRslt_KM.mat');
inspect_policy_results;

SimuRslt = simulate_KM(IterRslt);
save('SimuRslt_KM.mat','IterRslt','SimuRslt');
inspect_simulation_results;
main_simulate_irf;