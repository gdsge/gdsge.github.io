clear;
% gndsge_codegen('bianchi2011');
shock_process = load('shock_process.mat');

options = struct;
options.yT = shock_process.yT;
options.yN = shock_process.yN;
options.shock_trans = shock_process.shock_trans;
IterRslt = iter_bianchi2011(options);
SimuRslt = simulate_bianchi2011(IterRslt);

%%% Policy functions %%%%%%%%%
figure; 
subplot(2,1,1); hold on;
plot(IterRslt.var_state.b,IterRslt.var_aux.bNext(1,:),'ro-');
plot(IterRslt.var_state.b,IterRslt.var_aux.bNext(4,:),'kx-');
title('Policy Functions for Next Period Bond Holding, $b''$','interpreter','latex','FontSize',12);
xlabel('Current Bond Holding, $b$','FontSize',12,'interpreter','latex');

subplot(2,1,2); hold on;
plot(IterRslt.var_state.b,IterRslt.var_policy.pN(1,:),'ro-');
plot(IterRslt.var_state.b,IterRslt.var_policy.pN(4,:),'kx-');
title('Policy Functions for Non-tradable Good Price, $p^N$','interpreter','latex','FontSize',12);
xlabel('Current Bond Holding, $b$','FontSize',12,'interpreter','latex');
legend({'$y_t^T$ Lowest, $y_t^N$ Lowest','$y_t^T$ Highest, $y_t^N$ Lowest'},'Location','SouthEast','interpreter','latex','FontSize',12);
% print('figures/policy_combined.png','-dpng');

figure; hold on;
hh = histogram(SimuRslt.b(:,500:end),50,'Normalization','probability');
[density,grid] = ksdensity(reshape(SimuRslt.b(:,500:end),1,[]));
density = density*hh.BinWidth;
plot(grid,density,'r-','LineWidth',2);
title('Histogram and Kernel Density of Bond Holding','interpreter','latex','FontSize',12);
xlabel('Bond Holding, $b$','FontSize',12,'interpreter','latex');
ylabel('Fractions','interpreter','latex');
% print('figures/histogram_b.png','-dpng');
