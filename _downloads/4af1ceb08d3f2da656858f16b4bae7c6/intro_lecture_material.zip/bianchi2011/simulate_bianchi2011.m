function SimuRslt = simulate_bianchi2011(IterRslt,GNDSGE_OPTIONS)
%% Add path
if ispc
    BLAS_FILE = 'essential_blas.dll';
    PATH_DELIMITER = ';';
    
    GDSGE_TOOLBOX_ROOT = fileparts(which(BLAS_FILE));
    if ~any(strcmp(strsplit(getenv('PATH'),PATH_DELIMITER),GDSGE_TOOLBOX_ROOT))
        setenv('PATH',[getenv('PATH'),PATH_DELIMITER,GDSGE_TOOLBOX_ROOT]);
    end
    
    clear BLAS_FILE PATH_DELIMITER GDSGE_TOOLBOX_ROOT
elseif ismac
    if exist('./essential_blas.dylib','file') == 0
        copyfile(which('essential_blas.dylib'),'./');
    end
end

%% Simulate code starts here
TolEq = 1e-6;
TolSol = 1e-8;
TolFun = 1e-8;
PrintFreq = 10;
SaveFreq = 10;
SimuPrintFreq = 1000;
SimuSaveFreq = inf;
NumThreads = feature('numcores');
MaxIter = inf;
MaxMinorIter = inf;
num_samples = 1;
num_periods = 1000;
SolMaxIter = 200;

% task constants
MEX_TASK_INIT = 0;
MEX_TASK_INF_HORIZON = 1;

% DEBUG flag
GNDSGE_DEBUG_EVAL_ONLY = 0;

v2struct(IterRslt.pp);

INTERP_ORDER = 4;
EXTRAP_ORDER = 2;
OutputInterpOrder = 2;
USE_SPLINE = 1;
GNDSGE_USE_OLD_VEC = 0;
USE_ASG = 0;
USE_PCHIP = 0;
SIMU_INTERP = 0;
SIMU_RESOLVE = 1;
SimuSeed = 0823;
AsgMinLevel = 4;
AsgMaxLevel = 10;
AsgThreshold = 1e-2;
AsgOutputMaxLevel = 10;
AsgOutputThreshold = 1e-2;
IterSaveAll = 0;
SkipModelInit = 0;
GNDSGE_EMPTY = [];
GNDSGE_ASG_FIX_GRID = 0;
UseModelId = 0;
MinBatchSol = 1;
UseAdaptiveBound = 1;
UseAdaptiveBoundInSol = 0;
EnforceSimuStateInbound = 1;
rng(0823);
DEFAULT_PARAMETERS_END_HERE = true;
r = 0.04;
sigma = 2;
eta = 1/0.83 - 1;
kappaN = 0.32;
kappaT = 0.32;
omega = 0.31;
beta = 0.91;
bPts = 101;
bMin=-1.1;
bMax=0.0;
b=linspace(bMin,bMax,bPts);
shock_num=16;
shock_trans = 1/shock_num*ones(shock_num,shock_num);
yT = ones(1,shock_num);
yN = ones(1,shock_num);
num_periods = 1000;
num_samples = 100;


GEN_SHOCK_START_PERIOD = 1;

shock_trans = IterRslt.shock_trans;
v2struct(IterRslt.params);
v2struct(IterRslt.var_shock);
v2struct(IterRslt.var_state);

if nargin>=2
    v2struct(GNDSGE_OPTIONS)
end

%% Construct interpolation for solutions
GNDSGE_PP=struct('form','MKL','breaks',{{1:shock_num,b}},...
    'Values',reshape(IterRslt.GNDSGE_PROB.GNDSGE_SOL, [numel(IterRslt.GNDSGE_PROB.GNDSGE_SOL)/prod(IterRslt.GNDSGE_PROB.GNDSGE_SIZE),IterRslt.GNDSGE_PROB.GNDSGE_SIZE]),...
    'coefs',[],'order',[2 OutputInterpOrder*ones(1,length({b}))],'Method',[],...
    'ExtrapolationOrder',[],'thread',NumThreads, ...
    'orient','curvefit');
GNDSGE_PP=myinterp(GNDSGE_PP);

GNDSGE_NPROB = num_samples;

SimuRslt.shock = ones(num_samples,num_periods+1);
SimuRslt.b=zeros(num_samples,num_periods);
SimuRslt.c=zeros(num_samples,num_periods);
SimuRslt.pN=zeros(num_samples,num_periods);


SimuRslt.b(:,1)=0.0;
SimuRslt.shock(:,1)=1;


if nargin>1 && isfield(GNDSGE_OPTIONS,'init')
    SimuRslt.b(:,1:size(GNDSGE_OPTIONS.init.b,2))=GNDSGE_OPTIONS.init.b;
SimuRslt.shock(:,1:size(GNDSGE_OPTIONS.init.shock,2))=GNDSGE_OPTIONS.init.shock;

end

if any(SimuRslt.shock(:,1)>shock_num)
    error('initial shock exceeds shock_num');
end

GNDSGE_LB = -1e20*ones(4,GNDSGE_NPROB);
GNDSGE_UB = 1e20*ones(4,GNDSGE_NPROB);
GNDSGE_LB(1,:)=0.0;
GNDSGE_UB(1,:)=10.0;
GNDSGE_LB(2,:)=0.0;
GNDSGE_UB(2,:)=1.0;
GNDSGE_LB(3,:)=0.0;
GNDSGE_UB(3,:)=10.0;
GNDSGE_LB(4,:)=0.0;
GNDSGE_UB(4,:)=10.0;



% Use the largest bound in IterSol
GNDSGE_LB = repmat(min(IterRslt.GNDSGE_PROB.GNDSGE_LB,[],2),[1,GNDSGE_NPROB]);
GNDSGE_UB = repmat(max(IterRslt.GNDSGE_PROB.GNDSGE_UB,[],2),[1,GNDSGE_NPROB]);

GNDSGE_SKIP = zeros(1,GNDSGE_NPROB);
GNDSGE_EQVAL = 1e20*ones(4,GNDSGE_NPROB);
GNDSGE_F = 1e20*ones(1,GNDSGE_NPROB);
GNDSGE_SOL = zeros(4,GNDSGE_NPROB);
GNDSGE_AUX = zeros(3,GNDSGE_NPROB);

%% Generate random number
SimuRslt.shock(:,GEN_SHOCK_START_PERIOD:end) = gen_discrete_markov_rn(shock_trans,num_samples,length(GEN_SHOCK_START_PERIOD:num_periods+1),...
    SimuRslt.shock(:,GEN_SHOCK_START_PERIOD),SimuSeed);

MEX_TASK_NAME = MEX_TASK_INF_HORIZON;
GNDSGE_SHOCK_VAR_INDEX_BASE = ([0:num_samples-1]')*shock_num;

tic;
for GNDSGE_t=1:num_periods
    % Reuse the init inbound and tensor code
    % Map grid to current variable
    shock = SimuRslt.shock(:,GNDSGE_t);
    b=SimuRslt.b(:,GNDSGE_t);

    
    GNDSGE_data0 = repmat([shock_num;r(:);sigma(:);eta(:);kappaN(:);kappaT(:);omega(:);beta(:);shock_trans(:);yT(:);yN(:); ],1,GNDSGE_NPROB);
    
    
    
    % Use interpolation as initial values
%     %{
    if GNDSGE_t>0
        GNDSGE_SOL = myinterp_mex(int32(NumThreads),GNDSGE_PP.breaks,GNDSGE_PP.coefs,...
            int32(GNDSGE_PP.pieces),int32(GNDSGE_PP.order),int32(GNDSGE_PP.dim),'not-a-knot',[SimuRslt.shock(:,GNDSGE_t)';SimuRslt.b(:,GNDSGE_t)'],[],[],[]);
    end
    %}
    
    if UseAdaptiveBoundInSol==1
        % Tentatively adjust the bound
        GNDSGE_LB_OLD = GNDSGE_LB;
        GNDSGE_UB_OLD = GNDSGE_UB;
        
        
        
        % Hitting lower bound
        GNDSGE_SOL_hitting_lower_bound = abs(GNDSGE_SOL - GNDSGE_LB_OLD) < 1e-8;
        GNDSGE_SOL_hitting_upper_bound = abs(GNDSGE_SOL - GNDSGE_UB_OLD) < 1e-8;
        
        % Adjust for those hitting lower bound or upper bound
        GNDSGE_LB(~GNDSGE_SOL_hitting_lower_bound) = GNDSGE_LB_OLD(~GNDSGE_SOL_hitting_lower_bound);
        GNDSGE_UB(~GNDSGE_SOL_hitting_upper_bound) = GNDSGE_UB_OLD(~GNDSGE_SOL_hitting_upper_bound);
    end

    % Construct tensor variable
    
    
    % Reconstruct data
    GNDSGE_DATA = [GNDSGE_data0;shock(:)';b(:)';   ];
    
    % Solve problems
    GNDSGE_SKIP = zeros(1,GNDSGE_NPROB);
    [GNDSGE_SOL,GNDSGE_F,GNDSGE_AUX,GNDSGE_EQVAL,GNDSGE_OPT_INFO] = mex_bianchi2011(GNDSGE_SOL,GNDSGE_LB,GNDSGE_UB,GNDSGE_DATA,GNDSGE_SKIP,GNDSGE_F,GNDSGE_AUX,GNDSGE_EQVAL);
    while (max(isnan(GNDSGE_F)) || max(GNDSGE_F(:))>TolSol)
        GNDSGE_X0Rand = rand(size(GNDSGE_SOL)) .* (GNDSGE_UB-GNDSGE_LB) + GNDSGE_LB;
        NeedResolved = (GNDSGE_F>TolSol) | isnan(GNDSGE_F);
        GNDSGE_SOL(:,NeedResolved) = GNDSGE_X0Rand(:,NeedResolved);
        GNDSGE_SKIP(~NeedResolved) = 1;
        
        [GNDSGE_SOL,GNDSGE_F,GNDSGE_AUX,GNDSGE_EQVAL,GNDSGE_OPT_INFO] = mex_bianchi2011(GNDSGE_SOL,GNDSGE_LB,GNDSGE_UB,GNDSGE_DATA,GNDSGE_SKIP,GNDSGE_F,GNDSGE_AUX,GNDSGE_EQVAL);
    
        if UseAdaptiveBoundInSol==1
            % Tentatively adjust the bound
            GNDSGE_LB_OLD = GNDSGE_LB;
            GNDSGE_UB_OLD = GNDSGE_UB;
            
            
            
            % Hitting lower bound
            GNDSGE_SOL_hitting_lower_bound = abs(GNDSGE_SOL - GNDSGE_LB_OLD) < 1e-8;
            GNDSGE_SOL_hitting_upper_bound = abs(GNDSGE_SOL - GNDSGE_UB_OLD) < 1e-8;
            
            % Adjust for those hitting lower bound or upper bound
            GNDSGE_LB(~GNDSGE_SOL_hitting_lower_bound) = GNDSGE_LB_OLD(~GNDSGE_SOL_hitting_lower_bound);
            GNDSGE_UB(~GNDSGE_SOL_hitting_upper_bound) = GNDSGE_UB_OLD(~GNDSGE_SOL_hitting_upper_bound);
        end
    end
    
    nbNext=GNDSGE_SOL(1:1,:);
mu=GNDSGE_SOL(2:2,:);
cT=GNDSGE_SOL(3:3,:);
pN=GNDSGE_SOL(4:4,:);

    
    c=GNDSGE_AUX(1,:);
lambda=GNDSGE_AUX(2,:);
bNext=GNDSGE_AUX(3,:);

    
    GNDSGE_SHOCK_VAR_LINEAR_INDEX = SimuRslt.shock(:,GNDSGE_t+1) + GNDSGE_SHOCK_VAR_INDEX_BASE;
    SimuRslt.c(:,GNDSGE_t)=c;
SimuRslt.pN(:,GNDSGE_t)=pN;
SimuRslt.b(:,GNDSGE_t+1) = bNext(:);



    
    
    
    if mod(GNDSGE_t,SimuPrintFreq)==0
        fprintf('Periods: %d\n', GNDSGE_t);
        SimuRsltNames = fieldnames(SimuRslt);
        for GNDSGE_field = 1:length(SimuRsltNames)
            fprintf('%8s', SimuRsltNames{GNDSGE_field});
        end
        fprintf('\n');
        for GNDSGE_field = 1:length(SimuRsltNames)
            fprintf('%8.4g', SimuRslt.(SimuRsltNames{GNDSGE_field})(1,GNDSGE_t));
        end
        fprintf('\n');
        toc;
        tic;
    end
    
    if mod(GNDSGE_t,SimuSaveFreq)==0
        save(['SimuRslt_bianchi2011_' num2str(GNDSGE_t) '.mat'], 'SimuRslt');
    end
end
end