function [IterRslt,IterFlag] = iter_bianchi2011(GNDSGE_OPTIONS)
%% Add path
if ispc
    BLAS_FILE = 'essential_blas.dll';
    PATH_DELIMITER = ';';
    
    GDSGE_TOOLBOX_ROOT = fileparts(which(BLAS_FILE));
    if ~any(strcmp(strsplit(getenv('PATH'),PATH_DELIMITER),GDSGE_TOOLBOX_ROOT))
        setenv('PATH',[getenv('PATH'),PATH_DELIMITER,GDSGE_TOOLBOX_ROOT]);
    end
    
    clear BLAS_FILE PATH_DELIMITER GDSGE_TOOLBOX_ROOT
elseif ismac
    if exist('./essential_blas.dylib','file') == 0
        copyfile(which('essential_blas.dylib'),'./');
    end
end

%% Iter code starts here
TolEq = 1e-6;
TolSol = 1e-8;
TolFun = 1e-8;
PrintFreq = 10;
SaveFreq = 10;
SimuPrintFreq = 1000;
SimuSaveFreq = inf;
NumThreads = feature('numcores');
MaxIter = inf;
MaxMinorIter = inf;
num_samples = 1;
num_periods = 1000;
SolMaxIter = 200;

% task constants
MEX_TASK_INIT = 0;
MEX_TASK_INF_HORIZON = 1;

% DEBUG flag
GNDSGE_DEBUG_EVAL_ONLY = 0;
INTERP_ORDER = 4;
EXTRAP_ORDER = 2;
OutputInterpOrder = 2;
USE_SPLINE = 1;
GNDSGE_USE_OLD_VEC = 0;
USE_ASG = 0;
USE_PCHIP = 0;
SIMU_INTERP = 0;
SIMU_RESOLVE = 1;
SimuSeed = 0823;
AsgMinLevel = 4;
AsgMaxLevel = 10;
AsgThreshold = 1e-2;
AsgOutputMaxLevel = 10;
AsgOutputThreshold = 1e-2;
IterSaveAll = 0;
SkipModelInit = 0;
GNDSGE_EMPTY = [];
GNDSGE_ASG_FIX_GRID = 0;
UseModelId = 0;
MinBatchSol = 1;
UseAdaptiveBound = 1;
UseAdaptiveBoundInSol = 0;
EnforceSimuStateInbound = 1;
rng(0823);
DEFAULT_PARAMETERS_END_HERE = true;
r = 0.04;
sigma = 2;
eta = 1/0.83 - 1;
kappaN = 0.32;
kappaT = 0.32;
omega = 0.31;
beta = 0.91;
bPts = 101;
bMin=-1.1;
bMax=0.0;
b=linspace(bMin,bMax,bPts);
shock_num=16;
shock_trans = 1/shock_num*ones(shock_num,shock_num);
yT = ones(1,shock_num);
yN = ones(1,shock_num);


if nargin>=1
    v2struct(GNDSGE_OPTIONS)
end
  
assert(exist('shock_num','var')==1);
assert(length(yT)==16);
assert(length(yN)==16);
assert(size(shock_trans,1)==16);
assert(size(shock_trans,2)==16);


%% Solve the last period problem
if ~SkipModelInit
    MEX_TASK_NAME = MEX_TASK_INIT;
    
    [GNDSGE_TENSOR_shockIdx,GNDSGE_TENSOR_b]=ndgrid(1:shock_num,b);
GNDSGE_TENSOR_yT=ndgrid(yT,b);
GNDSGE_TENSOR_yN=ndgrid(yN,b);
GNDSGE_NPROB=numel(GNDSGE_TENSOR_shockIdx);

    
    
    
    GNDSGE_SIZE = size(GNDSGE_TENSOR_shockIdx);
    GNDSGE_SIZE_STATE = num2cell(GNDSGE_SIZE(2:end));
    
    GNDSGE_LB = -1e20*ones(1,GNDSGE_NPROB);
GNDSGE_UB = 1e20*ones(1,GNDSGE_NPROB);
GNDSGE_LB(1,:)=-1.0;
GNDSGE_UB(1,:)=1.0;

    
    GNDSGE_EQVAL = 1e20*ones(1,GNDSGE_NPROB);
    GNDSGE_F = 1e20*ones(1,GNDSGE_NPROB);
    GNDSGE_SOL = zeros(1,GNDSGE_NPROB);
    GNDSGE_X0 = rand(size(GNDSGE_SOL)) .* (GNDSGE_UB-GNDSGE_LB) + GNDSGE_LB;
    GNDSGE_SOL(:) = GNDSGE_X0;
    GNDSGE_AUX = zeros(2,GNDSGE_NPROB);
    GNDSGE_SKIP = zeros(1,GNDSGE_NPROB);
    GNDSGE_DATA = zeros(298,GNDSGE_NPROB);
    
    GNDSGE_DATA(:) = [repmat([shock_num;r(:);sigma(:);eta(:);kappaN(:);kappaT(:);omega(:);beta(:);shock_trans(:);yT(:);yN(:); ],1,GNDSGE_NPROB);GNDSGE_TENSOR_shockIdx(:)';GNDSGE_TENSOR_b(:)';   ];
    
    GNDSGE_F(:) = 1e20;
GNDSGE_SKIP(:) = 0;

[GNDSGE_SOL,GNDSGE_F,GNDSGE_AUX,GNDSGE_EQVAL,GNDSGE_OPT_INFO] = mex_bianchi2011(GNDSGE_SOL,GNDSGE_LB,GNDSGE_UB,GNDSGE_DATA,GNDSGE_SKIP,GNDSGE_F,GNDSGE_AUX,GNDSGE_EQVAL);
% Randomzie for nonconvert point
GNDSGE_MinorIter = 0;
numNeedResolvedAfter = inf;
while ((max(isnan(GNDSGE_F)) || max(GNDSGE_F(:))>TolSol) && GNDSGE_MinorIter<MaxMinorIter)
    % Repeatedly use the nearest point as initial guess
    NeedResolved = (GNDSGE_F>TolSol) | isnan(GNDSGE_F);
    numNeedResolved = sum(NeedResolved);
    while numNeedResolvedAfter ~= numNeedResolved
        NeedResolved = (GNDSGE_F>TolSol) | isnan(GNDSGE_F);
        numNeedResolved = sum(NeedResolved);
        % Use the nearest point as initial guess
        for i_dim = 1:length(GNDSGE_SIZE)
            stride = prod(GNDSGE_SIZE(1:i_dim-1));
            
            NeedResolved = (GNDSGE_F>TolSol) | isnan(GNDSGE_F);
            GNDSGE_SKIP(:) = 1;
            for GNDSGE_i = 1:numel(GNDSGE_F)
                if NeedResolved(GNDSGE_i) && GNDSGE_i-stride>=1
                    GNDSGE_idx = GNDSGE_i-stride;
                    if ~NeedResolved(GNDSGE_idx)
                        GNDSGE_SOL(:,GNDSGE_i) = GNDSGE_SOL(:,GNDSGE_idx);
                        GNDSGE_SKIP(GNDSGE_i) = 0;
                    end
                end
            end
            [GNDSGE_SOL,GNDSGE_F,GNDSGE_AUX,GNDSGE_EQVAL,GNDSGE_OPT_INFO] = mex_bianchi2011(GNDSGE_SOL,GNDSGE_LB,GNDSGE_UB,GNDSGE_DATA,GNDSGE_SKIP,GNDSGE_F,GNDSGE_AUX,GNDSGE_EQVAL);
            
            NeedResolved = (GNDSGE_F>TolSol) | isnan(GNDSGE_F);
            GNDSGE_SKIP(:) = 1;
            for GNDSGE_i = 1:numel(GNDSGE_F)
                if NeedResolved(GNDSGE_i) && GNDSGE_i+stride<=numel(GNDSGE_F)
                    GNDSGE_idx = GNDSGE_i+stride;
                    if ~NeedResolved(GNDSGE_idx)
                        GNDSGE_SOL(:,GNDSGE_i) = GNDSGE_SOL(:,GNDSGE_idx);
                        GNDSGE_SKIP(GNDSGE_i) = 0;
                    end
                end
            end
            [GNDSGE_SOL,GNDSGE_F,GNDSGE_AUX,GNDSGE_EQVAL,GNDSGE_OPT_INFO] = mex_bianchi2011(GNDSGE_SOL,GNDSGE_LB,GNDSGE_UB,GNDSGE_DATA,GNDSGE_SKIP,GNDSGE_F,GNDSGE_AUX,GNDSGE_EQVAL);
        end
        
        NeedResolvedAfter = (GNDSGE_F>TolSol) | isnan(GNDSGE_F);
        numNeedResolvedAfter = sum(NeedResolvedAfter);
    end
    
    % Use randomize as initial guess
    GNDSGE_X0Rand = rand(size(GNDSGE_SOL)) .* (GNDSGE_UB-GNDSGE_LB) + GNDSGE_LB;
    NeedResolved = (GNDSGE_F>TolSol) | isnan(GNDSGE_F);
    GNDSGE_SOL(:,NeedResolved) = GNDSGE_X0Rand(:,NeedResolved);
    GNDSGE_SKIP(:) = 0;
    GNDSGE_SKIP(~NeedResolved) = 1;
    
    [GNDSGE_SOL,GNDSGE_F,GNDSGE_AUX,GNDSGE_EQVAL,GNDSGE_OPT_INFO] = mex_bianchi2011(GNDSGE_SOL,GNDSGE_LB,GNDSGE_UB,GNDSGE_DATA,GNDSGE_SKIP,GNDSGE_F,GNDSGE_AUX,GNDSGE_EQVAL);

    if UseAdaptiveBoundInSol==1 && exist('GNDSGE_Iter','var')>0
        % Tentatively adjust the bound
        GNDSGE_LB_OLD = GNDSGE_LB;
        GNDSGE_UB_OLD = GNDSGE_UB;
        
        
        
        
        % Hitting lower bound
        GNDSGE_SOL_hitting_lower_bound = abs(GNDSGE_SOL - GNDSGE_LB_OLD) < 1e-8;
        GNDSGE_SOL_hitting_upper_bound = abs(GNDSGE_SOL - GNDSGE_UB_OLD) < 1e-8;
        
        % Adjust for those hitting lower bound or upper bound
        GNDSGE_LB(~GNDSGE_SOL_hitting_lower_bound) = GNDSGE_LB_OLD(~GNDSGE_SOL_hitting_lower_bound);
        GNDSGE_UB(~GNDSGE_SOL_hitting_upper_bound) = GNDSGE_UB_OLD(~GNDSGE_SOL_hitting_upper_bound);
        
        GNDSGE_MinorIter = GNDSGE_MinorIter+1;
    end
    
    GNDSGE_MinorIter = GNDSGE_MinorIter+1;
end
    
    dummy=GNDSGE_SOL(1:1,:);

    
    c=GNDSGE_AUX(1,:);
lambda=GNDSGE_AUX(2,:);

    
    
end

%% Solve the infinite horizon problem
[GNDSGE_TENSOR_shockIdx,GNDSGE_TENSOR_b]=ndgrid(1:shock_num,b);
GNDSGE_TENSOR_yT=ndgrid(yT,b);
GNDSGE_TENSOR_yN=ndgrid(yN,b);
GNDSGE_NPROB=numel(GNDSGE_TENSOR_shockIdx);




GNDSGE_SIZE = size(GNDSGE_TENSOR_shockIdx);
GNDSGE_SIZE_STATE = num2cell(GNDSGE_SIZE(2:end));

GNDSGE_LB = -1e20*ones(4,GNDSGE_NPROB);
GNDSGE_UB = 1e20*ones(4,GNDSGE_NPROB);
GNDSGE_LB(1,:)=0.0;
GNDSGE_UB(1,:)=10.0;
GNDSGE_LB(2,:)=0.0;
GNDSGE_UB(2,:)=1.0;
GNDSGE_LB(3,:)=0.0;
GNDSGE_UB(3,:)=10.0;
GNDSGE_LB(4,:)=0.0;
GNDSGE_UB(4,:)=10.0;


GNDSGE_EQVAL = 1e20*ones(4,GNDSGE_NPROB);
GNDSGE_F = 1e20*ones(1,GNDSGE_NPROB);
GNDSGE_SOL = zeros(4,GNDSGE_NPROB);
GNDSGE_X0 = rand(size(GNDSGE_SOL)) .* (GNDSGE_UB-GNDSGE_LB) + GNDSGE_LB;
GNDSGE_SOL(:) = GNDSGE_X0;
GNDSGE_AUX = zeros(3,GNDSGE_NPROB);
GNDSGE_SKIP = zeros(1,GNDSGE_NPROB);
GNDSGE_DATA = zeros(298,GNDSGE_NPROB);

if ~( nargin>=1 && isfield(GNDSGE_OPTIONS,'WarmUp') && isfield(GNDSGE_OPTIONS.WarmUp,'var_interp') )
    lambda_interp=zeros(GNDSGE_SIZE);
lambda_interp(:)=lambda;

    
    GNDSGE_INTERP_ORDER = INTERP_ORDER*ones(1,length(GNDSGE_SIZE_STATE));
GNDSGE_EXTRAP_ORDER = EXTRAP_ORDER*ones(1,length(GNDSGE_SIZE_STATE));

GNDSGE_PP_lambda_interp=struct('form','pp','breaks',{{b}},'Values',reshape(lambda_interp,[],GNDSGE_SIZE_STATE{:}),'coefs',[],'order',GNDSGE_INTERP_ORDER,'Method',[],'ExtrapolationOrder',GNDSGE_EXTRAP_ORDER,'thread',NumThreads,'orient','curvefit');
GNDSGE_PP_lambda_interp=myinterp(myinterp(GNDSGE_PP_lambda_interp));



% Construct the vectorized spline
if ~GNDSGE_USE_OLD_VEC
    GNDSGE_SPLINE_VEC = convert_to_interp_eval_array({GNDSGE_PP_lambda_interp});
end

end

GNDSGE_Metric = 1;
GNDSGE_Iter = 0;
IS_WARMUP_LOOP = 0;

if nargin>=1 && isfield(GNDSGE_OPTIONS,'WarmUp')
    if isfield(GNDSGE_OPTIONS.WarmUp,'var_interp')
        v2struct(GNDSGE_OPTIONS.WarmUp.var_interp);
        GNDSGE_TEMP = v2struct(b,GNDSGE_SIZE_STATE);
        GNDSGE_SIZE_STATE = num2cell(GNDSGE_OPTIONS.WarmUp.GNDSGE_PROB.GNDSGE_SIZE(2:end));
        v2struct(GNDSGE_OPTIONS.WarmUp.var_state);
        GNDSGE_INTERP_ORDER = INTERP_ORDER*ones(1,length(GNDSGE_SIZE_STATE));
GNDSGE_EXTRAP_ORDER = EXTRAP_ORDER*ones(1,length(GNDSGE_SIZE_STATE));

GNDSGE_PP_lambda_interp=struct('form','pp','breaks',{{b}},'Values',reshape(lambda_interp,[],GNDSGE_SIZE_STATE{:}),'coefs',[],'order',GNDSGE_INTERP_ORDER,'Method',[],'ExtrapolationOrder',GNDSGE_EXTRAP_ORDER,'thread',NumThreads,'orient','curvefit');
GNDSGE_PP_lambda_interp=myinterp(myinterp(GNDSGE_PP_lambda_interp));



% Construct the vectorized spline
if ~GNDSGE_USE_OLD_VEC
    GNDSGE_SPLINE_VEC = convert_to_interp_eval_array({GNDSGE_PP_lambda_interp});
end

        v2struct(GNDSGE_TEMP);
        IS_WARMUP_LOOP = 1;
    end
    if isfield(GNDSGE_OPTIONS.WarmUp,'Iter')
        GNDSGE_Iter = GNDSGE_OPTIONS.WarmUp.Iter;
    end
    if isfield(GNDSGE_OPTIONS.WarmUp,'GNDSGE_PROB') && size(GNDSGE_OPTIONS.WarmUp.GNDSGE_PROB.GNDSGE_SOL,1)==size(GNDSGE_SOL,1)
        % Interpolate SOL, LB, and UB
        GNDSGE_TEMP = v2struct(b,GNDSGE_SIZE_STATE);
        GNDSGE_SIZE_STATE = num2cell(GNDSGE_OPTIONS.WarmUp.GNDSGE_PROB.GNDSGE_SIZE);
        v2struct(GNDSGE_OPTIONS.WarmUp.var_state);
        GNDSGE_SOL_interp=struct('form','MKL','breaks',{{[1:shock_num],b}},'Values',reshape(GNDSGE_OPTIONS.WarmUp.GNDSGE_PROB.GNDSGE_SOL,[],GNDSGE_SIZE_STATE{:}),'coefs',[],'order',[2,GNDSGE_INTERP_ORDER],'Method',[],'ExtrapolationOrder',[2,GNDSGE_EXTRAP_ORDER],'thread',NumThreads,'orient','curvefit');
        GNDSGE_SOL_interp=myinterp(GNDSGE_SOL_interp);
        GNDSGE_LB_interp=struct('form','MKL','breaks',{{[1:shock_num],b}},'Values',reshape(GNDSGE_OPTIONS.WarmUp.GNDSGE_PROB.GNDSGE_LB,[],GNDSGE_SIZE_STATE{:}),'coefs',[],'order',[2,GNDSGE_INTERP_ORDER],'Method',[],'ExtrapolationOrder',[2,GNDSGE_EXTRAP_ORDER],'thread',NumThreads,'orient','curvefit');
        GNDSGE_LB_interp=myinterp(GNDSGE_LB_interp);
        GNDSGE_UB_interp=struct('form','MKL','breaks',{{[1:shock_num],b}},'Values',reshape(GNDSGE_OPTIONS.WarmUp.GNDSGE_PROB.GNDSGE_UB,[],GNDSGE_SIZE_STATE{:}),'coefs',[],'order',[2,GNDSGE_INTERP_ORDER],'Method',[],'ExtrapolationOrder',[2,GNDSGE_EXTRAP_ORDER],'thread',NumThreads,'orient','curvefit');
        GNDSGE_UB_interp=myinterp(GNDSGE_UB_interp);
        
        v2struct(GNDSGE_TEMP);
        GNDSGE_SOL = reshape(myinterp(GNDSGE_SOL_interp,[GNDSGE_TENSOR_shockIdx(:)';GNDSGE_TENSOR_b(:)'; ]),size(GNDSGE_SOL));
        GNDSGE_LB_NEW = reshape(myinterp(GNDSGE_LB_interp,[GNDSGE_TENSOR_shockIdx(:)';GNDSGE_TENSOR_b(:)'; ]),size(GNDSGE_LB));
        GNDSGE_UB_NEW = reshape(myinterp(GNDSGE_UB_interp,[GNDSGE_TENSOR_shockIdx(:)';GNDSGE_TENSOR_b(:)'; ]),size(GNDSGE_UB));
        
        
    end
end

stopFlag = false;
tic;
while(~stopFlag)
    GNDSGE_Iter = GNDSGE_Iter+1;
    
    

    
GNDSGE_DATA(:) = [repmat([shock_num;r(:);sigma(:);eta(:);kappaN(:);kappaT(:);omega(:);beta(:);shock_trans(:);yT(:);yN(:); ],1,GNDSGE_NPROB);GNDSGE_TENSOR_shockIdx(:)';GNDSGE_TENSOR_b(:)';   ];

MEX_TASK_NAME = MEX_TASK_INF_HORIZON;
GNDSGE_F(:) = 1e20;
GNDSGE_SKIP(:) = 0;

[GNDSGE_SOL,GNDSGE_F,GNDSGE_AUX,GNDSGE_EQVAL,GNDSGE_OPT_INFO] = mex_bianchi2011(GNDSGE_SOL,GNDSGE_LB,GNDSGE_UB,GNDSGE_DATA,GNDSGE_SKIP,GNDSGE_F,GNDSGE_AUX,GNDSGE_EQVAL);
% Randomzie for nonconvert point
GNDSGE_MinorIter = 0;
numNeedResolvedAfter = inf;
while ((max(isnan(GNDSGE_F)) || max(GNDSGE_F(:))>TolSol) && GNDSGE_MinorIter<MaxMinorIter)
    % Repeatedly use the nearest point as initial guess
    NeedResolved = (GNDSGE_F>TolSol) | isnan(GNDSGE_F);
    numNeedResolved = sum(NeedResolved);
    while numNeedResolvedAfter ~= numNeedResolved
        NeedResolved = (GNDSGE_F>TolSol) | isnan(GNDSGE_F);
        numNeedResolved = sum(NeedResolved);
        % Use the nearest point as initial guess
        for i_dim = 1:length(GNDSGE_SIZE)
            stride = prod(GNDSGE_SIZE(1:i_dim-1));
            
            NeedResolved = (GNDSGE_F>TolSol) | isnan(GNDSGE_F);
            GNDSGE_SKIP(:) = 1;
            for GNDSGE_i = 1:numel(GNDSGE_F)
                if NeedResolved(GNDSGE_i) && GNDSGE_i-stride>=1
                    GNDSGE_idx = GNDSGE_i-stride;
                    if ~NeedResolved(GNDSGE_idx)
                        GNDSGE_SOL(:,GNDSGE_i) = GNDSGE_SOL(:,GNDSGE_idx);
                        GNDSGE_SKIP(GNDSGE_i) = 0;
                    end
                end
            end
            [GNDSGE_SOL,GNDSGE_F,GNDSGE_AUX,GNDSGE_EQVAL,GNDSGE_OPT_INFO] = mex_bianchi2011(GNDSGE_SOL,GNDSGE_LB,GNDSGE_UB,GNDSGE_DATA,GNDSGE_SKIP,GNDSGE_F,GNDSGE_AUX,GNDSGE_EQVAL);
            
            NeedResolved = (GNDSGE_F>TolSol) | isnan(GNDSGE_F);
            GNDSGE_SKIP(:) = 1;
            for GNDSGE_i = 1:numel(GNDSGE_F)
                if NeedResolved(GNDSGE_i) && GNDSGE_i+stride<=numel(GNDSGE_F)
                    GNDSGE_idx = GNDSGE_i+stride;
                    if ~NeedResolved(GNDSGE_idx)
                        GNDSGE_SOL(:,GNDSGE_i) = GNDSGE_SOL(:,GNDSGE_idx);
                        GNDSGE_SKIP(GNDSGE_i) = 0;
                    end
                end
            end
            [GNDSGE_SOL,GNDSGE_F,GNDSGE_AUX,GNDSGE_EQVAL,GNDSGE_OPT_INFO] = mex_bianchi2011(GNDSGE_SOL,GNDSGE_LB,GNDSGE_UB,GNDSGE_DATA,GNDSGE_SKIP,GNDSGE_F,GNDSGE_AUX,GNDSGE_EQVAL);
        end
        
        NeedResolvedAfter = (GNDSGE_F>TolSol) | isnan(GNDSGE_F);
        numNeedResolvedAfter = sum(NeedResolvedAfter);
    end
    
    % Use randomize as initial guess
    GNDSGE_X0Rand = rand(size(GNDSGE_SOL)) .* (GNDSGE_UB-GNDSGE_LB) + GNDSGE_LB;
    NeedResolved = (GNDSGE_F>TolSol) | isnan(GNDSGE_F);
    GNDSGE_SOL(:,NeedResolved) = GNDSGE_X0Rand(:,NeedResolved);
    GNDSGE_SKIP(:) = 0;
    GNDSGE_SKIP(~NeedResolved) = 1;
    
    [GNDSGE_SOL,GNDSGE_F,GNDSGE_AUX,GNDSGE_EQVAL,GNDSGE_OPT_INFO] = mex_bianchi2011(GNDSGE_SOL,GNDSGE_LB,GNDSGE_UB,GNDSGE_DATA,GNDSGE_SKIP,GNDSGE_F,GNDSGE_AUX,GNDSGE_EQVAL);

    if UseAdaptiveBoundInSol==1 && exist('GNDSGE_Iter','var')>0
        % Tentatively adjust the bound
        GNDSGE_LB_OLD = GNDSGE_LB;
        GNDSGE_UB_OLD = GNDSGE_UB;
        
        
        
        
        % Hitting lower bound
        GNDSGE_SOL_hitting_lower_bound = abs(GNDSGE_SOL - GNDSGE_LB_OLD) < 1e-8;
        GNDSGE_SOL_hitting_upper_bound = abs(GNDSGE_SOL - GNDSGE_UB_OLD) < 1e-8;
        
        % Adjust for those hitting lower bound or upper bound
        GNDSGE_LB(~GNDSGE_SOL_hitting_lower_bound) = GNDSGE_LB_OLD(~GNDSGE_SOL_hitting_lower_bound);
        GNDSGE_UB(~GNDSGE_SOL_hitting_upper_bound) = GNDSGE_UB_OLD(~GNDSGE_SOL_hitting_upper_bound);
        
        GNDSGE_MinorIter = GNDSGE_MinorIter+1;
    end
    
    GNDSGE_MinorIter = GNDSGE_MinorIter+1;
end

nbNext=GNDSGE_SOL(1:1,:);
mu=GNDSGE_SOL(2:2,:);
cT=GNDSGE_SOL(3:3,:);
pN=GNDSGE_SOL(4:4,:);


c=GNDSGE_AUX(1,:);
lambda=GNDSGE_AUX(2,:);
bNext=GNDSGE_AUX(3,:);

    
    
    
    nbNext=reshape(nbNext,shock_num,[]);
mu=reshape(mu,shock_num,[]);
cT=reshape(cT,shock_num,[]);
pN=reshape(pN,shock_num,[]);
c=reshape(c,shock_num,[]);
lambda=reshape(lambda,shock_num,[]);
bNext=reshape(bNext,shock_num,[]);

    
    GNDSGE_NEW_lambda_interp = lambda;

    
    % Compute Metric
    if IS_WARMUP_LOOP==1
        GNDSGE_Metric = inf;
        IS_WARMUP_LOOP = 0;
    else
        GNDSGE_Metric = max([max(abs(GNDSGE_NEW_lambda_interp(:)-lambda_interp(:)))]);

    end
    
    % Update
    lambda_interp=GNDSGE_NEW_lambda_interp;

    
    
    
    
    
    stopFlag = GNDSGE_Metric<TolEq || GNDSGE_Iter>=MaxIter;
    
    GNDSGE_INTERP_ORDER = INTERP_ORDER*ones(1,length(GNDSGE_SIZE_STATE));
GNDSGE_EXTRAP_ORDER = EXTRAP_ORDER*ones(1,length(GNDSGE_SIZE_STATE));

GNDSGE_PP_lambda_interp=struct('form','pp','breaks',{{b}},'Values',reshape(lambda_interp,[],GNDSGE_SIZE_STATE{:}),'coefs',[],'order',GNDSGE_INTERP_ORDER,'Method',[],'ExtrapolationOrder',GNDSGE_EXTRAP_ORDER,'thread',NumThreads,'orient','curvefit');
GNDSGE_PP_lambda_interp=myinterp(myinterp(GNDSGE_PP_lambda_interp));



% Construct the vectorized spline
if ~GNDSGE_USE_OLD_VEC
    GNDSGE_SPLINE_VEC = convert_to_interp_eval_array({GNDSGE_PP_lambda_interp});
end

    
    if ( mod(GNDSGE_Iter,PrintFreq)==0 || stopFlag == true )
      fprintf(['Iter:%d, Metric:%g, maxF:%g\n'],GNDSGE_Iter,GNDSGE_Metric,max(GNDSGE_F));
      toc;
      tic;
    end
    
    if ( mod(GNDSGE_Iter,SaveFreq)==0 || stopFlag == true )
        nbNext=reshape(nbNext,GNDSGE_SIZE);
mu=reshape(mu,GNDSGE_SIZE);
cT=reshape(cT,GNDSGE_SIZE);
pN=reshape(pN,GNDSGE_SIZE);
lambda_interp=reshape(lambda_interp,GNDSGE_SIZE);
c=reshape(c,GNDSGE_SIZE);
lambda=reshape(lambda,GNDSGE_SIZE);
bNext=reshape(bNext,GNDSGE_SIZE);

        
        % Construct output variables
outputVarStack = cat(1,reshape(bNext,1,[]),reshape(pN,1,[]));

% Permute variables from order (shock, var, states) to order (var,
% shock, states)
outputVarStack = reshape(outputVarStack, [],shock_num,GNDSGE_SIZE_STATE{:});

output_interp=struct('form','MKL','breaks',{{1:shock_num,b}},...
    'Values',outputVarStack,...
    'coefs',[],'order',[2 OutputInterpOrder*ones(1,length({b}))],'Method',[],...
    'ExtrapolationOrder',[],'thread',NumThreads, ...
    'orient','curvefit');
IterRslt.output_interp=myinterp(output_interp);

output_var_index=struct();
output_var_index.bNext=1:1;
output_var_index.pN=2:2;

IterRslt.output_var_index = output_var_index;

        IterRslt.Metric = GNDSGE_Metric;
        IterRslt.Iter = GNDSGE_Iter;
        IterRslt.shock_num = shock_num;
        IterRslt.shock_trans = shock_trans;
        IterRslt.params = v2struct(r,sigma,eta,kappaN,kappaT,omega,beta,GNDSGE_EMPTY);
        IterRslt.var_shock = v2struct(yT,yN);
        IterRslt.var_state = v2struct(b);
        IterRslt.var_policy = v2struct(nbNext,mu,cT,pN);
        IterRslt.var_interp = v2struct(lambda_interp);
        IterRslt.var_aux = v2struct(c,lambda,bNext,GNDSGE_EMPTY);
        IterRslt.pp = v2struct(GNDSGE_PP_lambda_interp,GNDSGE_SPLINE_VEC,GNDSGE_EMPTY);
        IterRslt.GNDSGE_PROB = v2struct(GNDSGE_LB,GNDSGE_UB,GNDSGE_SOL,GNDSGE_F,GNDSGE_SIZE);
        IterRslt.var_others = v2struct(GNDSGE_EMPTY);

        if IterSaveAll
            save(['IterRslt_bianchi2011_' num2str(GNDSGE_Iter) '.mat']);
        else
            save(['IterRslt_bianchi2011_' num2str(GNDSGE_Iter) '.mat'],'IterRslt');
        end
    end
end
    

%% Return the success flag
IterFlag = 0;
end
