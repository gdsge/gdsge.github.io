clear;
gndsge_codegen('rbc');

IterRslt = iter_rbc;
SimuRslt = simulate_rbc(IterRslt);

figure;
plot(IterRslt.var_state.K, IterRslt.var_policy.K_next);
xlabel('K'); title('Policy Functions for Next Period K');

figure;
plot(IterRslt.var_state.K, IterRslt.var_policy.c);
xlabel('K'); title('Policy Functions for c');

figure;
histogram(SimuRslt.K); title('Histogram for K');

figure;
plot(SimuRslt.w(1:2,1:100)'); title('Sample Paths of Wages');

% Make the size of the shock larger
options.z = [0.95,1.05];
options.WarmUp = IterRslt;
IterRslt = iter_rbc(options);
figure;
plot(IterRslt.var_state.K, IterRslt.var_policy.K_next);
xlabel('K'); title('Policy Functions for Next Period K');
