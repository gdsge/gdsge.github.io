%clear;
%load('IterRslt_zlb.mat');
v2struct(IterRslt);
[KMesh,omegaMesh] = ndgrid(var_state.kF,var_state.omega);
s1 = 2;

figure;
subplot(2,2,1);
surf(KMesh,omegaMesh,squeeze(var_aux.xF(2,:,:)));
xlabel('$k$','Interpreter','Latex');
ylabel('$\omega$','Interpreter','Latex');
title('Farmer''s Consumption with $A_{t}=A_{2}$','Interpreter','Latex');
set(gca,'FontSize',18);
view([-136.7 32.4]);

subplot(2,2,2);
surf(KMesh,omegaMesh,squeeze(var_aux.bFnext(2,:,:)));
xlabel('$k$','Interpreter','Latex');
ylabel('$\omega$','Interpreter','Latex');
title('Farmer''s Bond Holding','Interpreter','Latex');
set(gca,'FontSize',18);
view([-136.7 32.4]);

subplot(2,2,3);
surf(KMesh,omegaMesh,squeeze(var_policy.kFnext(2,:,:)));
xlabel('$k$','Interpreter','Latex');
ylabel('$\omega$','Interpreter','Latex');
title('Farmer''s Capital Holding','Interpreter','Latex');
set(gca,'FontSize',18);
view([-136.7 32.4]);

subplot(2,2,4);
surf(KMesh,omegaMesh,squeeze(var_policy.q(2,:,:)));
xlabel('$k$','Interpreter','Latex');
ylabel('$\omega$','Interpreter','Latex');
title('Capital Price','Interpreter','Latex');
set(gca,'FontSize',18);
view([-136.7 32.4]);